# time_series
git clone https://github.com/cchantra/time_series.git

1. data_clean_visual: for cleaning data 
2. test_decompose: investigate signals, decompose into trend/seasonal
3. test_acf: test ACF/ PACF values and do simple ARIMA prediction (non-seasonal)
4. auto_arima: demonstrate the auto arima with python

requriement : data set download at

https://goo.gl/5CbnNn

